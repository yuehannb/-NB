import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../services/yolo_service.dart';
import '../models/detection_result.dart';
import '../models/custom_labels.dart';
import 'dart:async';

part 'detection_provider.g.dart';

/// 检测状态
enum DetectionMode {
  idle,
  detecting,
  paused,
  error,
}

/// 检测状态类
class DetectionState {
  final DetectionMode mode;
  final List<DetectionResult> results;
  final double fps;
  final double confidenceThreshold;
  final String? errorMessage;
  final Map<String, String> customLabels;
  final int totalDetections;
  final Map<String, int> labelStatistics;

  DetectionState({
    this.mode = DetectionMode.idle,
    this.results = const [],
    this.fps = 0.0,
    this.confidenceThreshold = 0.25,
    this.errorMessage,
    this.customLabels = const {},
    this.totalDetections = 0,
    this.labelStatistics = const {},
  });

  DetectionState copyWith({
    DetectionMode? mode,
    List<DetectionResult>? results,
    double? fps,
    double? confidenceThreshold,
    String? errorMessage,
    Map<String, String>? customLabels,
    int? totalDetections,
    Map<String, int>? labelStatistics,
  }) {
    return DetectionState(
      mode: mode ?? this.mode,
      results: results ?? this.results,
      fps: fps ?? this.fps,
      confidenceThreshold: confidenceThreshold ?? this.confidenceThreshold,
      errorMessage: errorMessage,
      customLabels: customLabels ?? this.customLabels,
      totalDetections: totalDetections ?? this.totalDetections,
      labelStatistics: labelStatistics ?? this.labelStatistics,
    );
  }
}

/// 检测服务提供者
@riverpod
YoloService yoloService(YoloServiceRef ref) {
  return YoloService();
}

/// 检测提供者
@riverpod
class DetectionNotifier extends _$DetectionNotifier {
  final CustomLabelsManager _labelsManager = CustomLabelsManager();
  final YoloService _yoloService = YoloService();
  bool _isProcessing = false;
  Timer? _detectionTimer;
  
  // 用于统计
  final Map<String, int> _statistics = {};
  int _totalDetections = 0;

  @override
  DetectionState build() {
    // 初始化时加载自定义标签
    _initializeLabels();
    return DetectionState();
  }

  /// 初始化标签管理器
  Future<void> _initializeLabels() async {
    try {
      await _labelsManager.initialize();
      final labels = _labelsManager.getAllLabels();
      state = state.copyWith(customLabels: labels);
    } catch (e) {
      print('标签初始化失败: $e');
    }
  }

  /// 初始化 YOLO 服务
  Future<void> initialize() async {
    try {
      await _yoloService.initialize();
      print('YOLO服务初始化成功');
    } catch (e) {
      state = state.copyWith(
        mode: DetectionMode.error,
        errorMessage: 'YOLO服务初始化失败: $e',
      );
    }
  }

  /// 开始检测
  void startDetection() async {
    if (!_yoloService.isModelLoaded) {
      await initialize();
    }

    state = state.copyWith(mode: DetectionMode.detecting);
    _isProcessing = true;
    
    // 重置统计
    _statistics.clear();
    _totalDetections = 0;
  }

  /// 停止检测
  void stopDetection() {
    state = state.copyWith(mode: DetectionMode.idle);
    _isProcessing = false;
    _detectionTimer?.cancel();
    _detectionTimer = null;
  }

  /// 暂停检测
  void pauseDetection() {
    state = state.copyWith(mode: DetectionMode.paused);
    _isProcessing = false;
  }

  /// 恢复检测
  void resumeDetection() {
    state = state.copyWith(mode: DetectionMode.detecting);
    _isProcessing = true;
  }

  /// 处理图像帧
  Future<void> processFrame(List<int> imageBytes) async {
    if (!_isProcessing) return;

    try {
      // 执行检测
      final results = await _yoloService.detect(
        imageBytes: Uint8List.fromList(imageBytes),
        confidenceThreshold: state.confidenceThreshold,
        customLabels: state.customLabels,
      );

      // 更新统计
      _updateStatistics(results);

      // 更新状态
      state = state.copyWith(
        results: results,
        totalDetections: _totalDetections,
        labelStatistics: Map.from(_statistics),
      );
    } catch (e) {
      print('检测过程出错: $e');
      // 不停止检测，继续下一帧
    }
  }

  /// 更新检测统计
  void _updateStatistics(List<DetectionResult> results) {
    _totalDetections += results.length;
    
    for (final result in results) {
      _statistics[result.label] = (_statistics[result.label] ?? 0) + 1;
    }
  }

  /// 设置置信度阈值
  void setConfidenceThreshold(double threshold) {
    state = state.copyWith(confidenceThreshold: threshold);
  }

  /// 更新自定义标签
  Future<void> updateCustomLabel(String originalLabel, String displayLabel) async {
    try {
      await _labelsManager.updateLabel(originalLabel, displayLabel);
      final updatedLabels = _labelsManager.getAllLabels();
      state = state.copyWith(customLabels: updatedLabels);
    } catch (e) {
      print('更新标签失败: $e');
    }
  }

  /// 批量更新自定义标签
  Future<void> updateCustomLabels(Map<String, String> labels) async {
    try {
      await _labelsManager.updateLabels(labels);
      final updatedLabels = _labelsManager.getAllLabels();
      state = state.copyWith(customLabels: updatedLabels);
    } catch (e) {
      print('批量更新标签失败: $e');
    }
  }

  /// 重置自定义标签
  Future<void> resetCustomLabels() async {
    try {
      await _labelsManager.resetToDefault();
      final defaultLabels = _labelsManager.getAllLabels();
      state = state.copyWith(customLabels: defaultLabels);
    } catch (e) {
      print('重置标签失败: $e');
    }
  }

  /// 清除检测统计
  void clearStatistics() {
    _statistics.clear();
    _totalDetections = 0;
    state = state.copyWith(
      totalDetections: 0,
      labelStatistics: {},
    );
  }

  /// 更新 FPS
  void updateFPS(double fps) {
    state = state.copyWith(fps: fps);
  }

  /// 处理错误
  void handleError(String errorMessage) {
    state = state.copyWith(
      mode: DetectionMode.error,
      errorMessage: errorMessage,
    );
  }

  /// 清除错误状态
  void clearError() {
    state = state.copyWith(
      errorMessage: null,
      mode: DetectionMode.idle,
    );
  }

  @override
  void dispose() {
    stopDetection();
    _yoloService.dispose();
    super.dispose();
  }
}

/// 检测状态提供者（便捷访问）
final detectionProviderProvider = Provider<DetectionState>((ref) {
  return ref.watch(detectionNotifierProvider);
});
