import 'package:flutter/material.dart';
import '../models/detection_result.dart';

/// 检测结果覆盖层组件
/// 在相机预览上绘制检测框和标签
class DetectionOverlay extends StatelessWidget {
  final List<DetectionResult> results;
  final Size imageSize;

  const DetectionOverlay({
    Key? key,
    required this.results,
    required this.imageSize,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (results.isEmpty) {
      return const SizedBox.shrink();
    }

    return CustomPaint(
      size: Size.infinite,
      painter: DetectionOverlayPainter(
        results: results,
        imageSize: imageSize,
      ),
    );
  }
}

/// 检测覆盖层绘制器
class DetectionOverlayPainter extends CustomPainter {
  final List<DetectionResult> results;
  final Size imageSize;

  DetectionOverlayPainter({
    required this.results,
    required this.imageSize,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // 计算缩放比例
    final scaleX = size.width / imageSize.width;
    final scaleY = size.height / imageSize.height;

    for (final result in results) {
      final box = result.boundingBox;
      
      // 缩放边界框坐标
      final rect = Rect.fromLTRB(
        box.left * scaleX,
        box.top * scaleY,
        box.right * scaleX,
        box.bottom * scaleY,
      );

      // 绘制边界框
      final paint = Paint()
        ..color = Colors.green
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0;
      
      canvas.drawRect(rect, paint);

      // 绘制标签背景
      final textPainter = TextPainter(
        text: TextSpan(
          text: '${result.label} ${(result.confidence * 100).toStringAsFixed(0)}%',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        textDirection: TextDirection.ltr,
      );

      textPainter.layout();

      // 标签背景矩形
      final labelHeight = textPainter.height + 8;
      final labelWidth = textPainter.width + 16;
      final labelRect = Rect.fromLTWH(
        rect.left,
        rect.top - labelHeight,
        labelWidth,
        labelHeight,
      );

      final backgroundPaint = Paint()
        ..color = Colors.green
        ..style = PaintingStyle.fill;

      canvas.drawRect(labelRect, backgroundPaint);

      // 绘制标签文本
      textPainter.paint(
        canvas,
        Offset(
          labelRect.left + 8,
          labelRect.top + 4,
        ),
      );
    }
  }

  @override
  bool shouldRepaint(covariant DetectionOverlayPainter oldDelegate) {
    return results != oldDelegate.results;
  }
}
