import 'package:flutter/material.dart';

/// FPS 计数器组件
/// 显示当前的检测帧率
class FPSCounter extends StatelessWidget {
  final double fps;

  const FPSCounter({
    Key? key,
    required this.fps,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.speed,
            color: Colors.green,
            size: 16,
          ),
          const SizedBox(width: 4),
          Text(
            '${fps.toStringAsFixed(1)} FPS',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
