import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/detection_provider.dart';
import '../services/camera_service.dart';
import '../widgets/camera_preview.dart';
import '../widgets/detection_overlay.dart';
import '../widgets/fps_counter.dart';

/// 主检测页面
/// 对应 Python 的 main_window.py 主窗口
class MainScreen extends ConsumerStatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends ConsumerState<MainScreen> {
  final CameraService _cameraService = CameraService();
  bool _isProcessingFrame = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  @override
  void dispose() {
    _cameraService.dispose();
    super.dispose();
  }

  /// 初始化相机和模型
  Future<void> _initialize() async {
    try {
      // 初始化相机
      await _cameraService.initialize();
      
      // 初始化 YOLO 服务
      await ref.read(detectionNotifierProvider.notifier).initialize();
      
      // 开始相机图像流
      _cameraService.startImageStream((image) {
        _handleCameraImage(image);
      });
      
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print('初始化失败: $e');
      ref.read(detectionNotifierProvider.notifier).handleError('初始化失败: $e');
    }
  }

  /// 处理相机图像
  Future<void> _handleCameraImage(CameraImage image) async {
    // 限制处理频率，避免阻塞UI
    if (_isProcessingFrame) return;
    _isProcessingFrame = true;

    try {
      // 更新 FPS
      final fps = _cameraService.updateFPS();
      ref.read(detectionNotifierProvider.notifier).updateFPS(fps);

      // 如果正在检测，处理图像
      final detectionState = ref.read(detectionNotifierProvider);
      if (detectionState.mode == DetectionMode.detecting) {
        // 转换图像为字节
        final imageBytes = CameraService.cameraImageToBytes(image);
        
        // 异步处理检测，不阻塞主线程
        _processDetectionAsync(imageBytes);
      }
    } catch (e) {
      print('处理图像失败: $e');
    } finally {
      // 延迟释放处理锁，控制检测频率
      Future.delayed(const Duration(milliseconds: 100), () {
        _isProcessingFrame = false;
      });
    }
  }

  /// 异步处理检测
  Future<void> _processDetectionAsync(Uint8List imageBytes) async {
    await ref.read(detectionNotifierProvider.notifier).processFrame(imageBytes);
  }

  @override
  Widget build(BuildContext context) {
    final detectionState = ref.watch(detectionNotifierProvider);
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      appBar: AppBar(
        title: const Text('YOLO 目标检测'),
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: theme.colorScheme.onPrimary,
        actions: [
          // 设置按钮
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => _showSettingsDialog(context),
          ),
          // 统计按钮
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: () => _showStatisticsDialog(context),
          ),
        ],
      ),
      body: Stack(
        children: [
          // 相机预览
          if (_cameraService.isInitialized)
            CameraPreviewWidget(
              cameraController: _cameraService.controller!,
            )
          else
            _buildLoadingWidget(),

          // 检测结果覆盖层
          if (detectionState.mode == DetectionMode.detecting &&
              detectionState.results.isNotEmpty)
            DetectionOverlay(
              results: detectionState.results,
              imageSize: Size(
                _cameraService.controller?.value.previewSize?.height.toDouble() ?? 0,
                _cameraService.controller?.value.previewSize?.width.toDouble() ?? 0,
              ),
            ),

          // FPS 显示
          if (detectionState.mode == DetectionMode.detecting)
            Positioned(
              top: 16,
              right: 16,
              child: FPSCounter(fps: detectionState.fps),
            ),

          // 控制按钮覆盖层
          Positioned(
            bottom: 32,
            left: 16,
            right: 16,
            child: _buildControlPanel(detectionState),
          ),

          // 错误提示
          if (detectionState.mode == DetectionMode.error &&
              detectionState.errorMessage != null)
            _buildErrorOverlay(detectionState.errorMessage!),
        ],
      ),
    );
  }

  /// 构建加载界面
  Widget _buildLoadingWidget() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 16),
          Text('正在初始化相机和模型...'),
        ],
      ),
    );
  }

  /// 构建控制面板
  Widget _buildControlPanel(DetectionState state) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // 开始/停止检测按钮
          _buildControlButton(
            icon: state.mode == DetectionMode.detecting
                ? Icons.stop
                : Icons.play_arrow,
            label: state.mode == DetectionMode.detecting ? '停止' : '开始',
            onPressed: state.mode == DetectionMode.detecting
                ? _stopDetection
                : _startDetection,
            color: state.mode == DetectionMode.detecting
                ? Colors.red
                : Colors.green,
          ),
          // 暂停/恢复按钮
          if (state.mode == DetectionMode.detecting ||
              state.mode == DetectionMode.paused)
            _buildControlButton(
              icon: state.mode == DetectionMode.paused
                  ? Icons.play_arrow
                  : Icons.pause,
              label: state.mode == DetectionMode.paused ? '恢复' : '暂停',
              onPressed: state.mode == DetectionMode.paused
                  ? _resumeDetection
                  : _pauseDetection,
              color: Colors.orange,
            ),
          // 切换相机按钮
          _buildControlButton(
            icon: Icons.flip_camera_ios,
            label: '切换',
            onPressed: _switchCamera,
            color: Colors.blue,
          ),
        ],
      ),
    );
  }

  /// 构建控制按钮
  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    required Color color,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
          child: IconButton(
            icon: Icon(icon, color: Colors.white),
            onPressed: onPressed,
            iconSize: 28,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  /// 构建错误覆盖层
  Widget _buildErrorOverlay(String errorMessage) {
    return Container(
      color: Colors.black.withOpacity(0.8),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline,
                size: 64,
                color: Colors.red,
              ),
              const SizedBox(height: 16),
              Text(
                errorMessage,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  ref.read(detectionNotifierProvider.notifier).clearError();
                },
                child: const Text('确定'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 开始检测
  void _startDetection() {
    ref.read(detectionNotifierProvider.notifier).startDetection();
  }

  /// 停止检测
  void _stopDetection() {
    ref.read(detectionNotifierProvider.notifier).stopDetection();
  }

  /// 暂停检测
  void _pauseDetection() {
    ref.read(detectionNotifierProvider.notifier).pauseDetection();
  }

  /// 恢复检测
  void _resumeDetection() {
    ref.read(detectionNotifierProvider.notifier).resumeDetection();
  }

  /// 切换相机
  Future<void> _switchCamera() async {
    try {
      await _cameraService.switchCamera();
      setState(() {});
    } catch (e) {
      print('切换相机失败: $e');
    }
  }

  /// 显示设置对话框
  void _showSettingsDialog(BuildContext context) {
    final detectionState = ref.read(detectionNotifierProvider);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('检测设置'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('置信度阈值: ${detectionState.confidenceThreshold.toStringAsFixed(2)}'),
            Slider(
              value: detectionState.confidenceThreshold,
              min: 0.0,
              max: 1.0,
              divisions: 100,
              label: detectionState.confidenceThreshold.toStringAsFixed(2),
              onChanged: (value) {
                ref.read(detectionNotifierProvider.notifier).setConfidenceThreshold(value);
              },
            ),
            const SizedBox(height: 16),
            Text('当前模式: ${_getModeText(detectionState.mode)}'),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
                _showCustomLabelsDialog(context);
              },
              icon: const Icon(Icons.edit),
              label: const Text('自定义标签'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  /// 显示自定义标签对话框
  void _showCustomLabelsDialog(BuildContext context) {
    final detectionState = ref.read(detectionNotifierProvider);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('自定义标签'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: detectionState.customLabels.length,
            itemBuilder: (context, index) {
              final originalLabel = detectionState.customLabels.keys.elementAt(index);
              final displayLabel = detectionState.customLabels[originalLabel];
              
              return ListTile(
                title: Text(originalLabel),
                subtitle: Text(displayLabel ?? originalLabel),
                trailing: IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _editCustomLabel(context, originalLabel, displayLabel ?? originalLabel),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await ref.read(detectionNotifierProvider.notifier).resetCustomLabels();
              if (mounted) Navigator.pop(context);
            },
            child: const Text('重置'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  /// 编辑自定义标签
  void _editCustomLabel(BuildContext context, String originalLabel, String currentLabel) {
    final controller = TextEditingController(text: currentLabel);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('编辑标签: $originalLabel'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            labelText: '显示名称',
            hintText: '输入新的标签名称',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              await ref.read(detectionNotifierProvider.notifier).updateCustomLabel(
                originalLabel,
                controller.text,
              );
              if (mounted) {
                Navigator.pop(context);
                Navigator.pop(context);
              }
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }

  /// 显示统计对话框
  void _showStatisticsDialog(BuildContext context) {
    final detectionState = ref.read(detectionNotifierProvider);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('检测统计'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('总检测数: ${detectionState.totalDetections}'),
            const SizedBox(height: 16),
            const Text('标签分布:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            SizedBox(
              height: 200,
              child: ListView.builder(
                itemCount: detectionState.labelStatistics.length,
                itemBuilder: (context, index) {
                  final label = detectionState.labelStatistics.keys.elementAt(index);
                  final count = detectionState.labelStatistics[label]!;
                  return ListTile(
                    title: Text(label),
                    trailing: Text('$count 次'),
                  );
                },
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              ref.read(detectionNotifierProvider.notifier).clearStatistics();
              if (mounted) Navigator.pop(context);
            },
            child: const Text('清除统计'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  /// 获取模式文本
  String _getModeText(DetectionMode mode) {
    switch (mode) {
      case DetectionMode.idle:
        return '空闲';
      case DetectionMode.detecting:
        return '检测中';
      case DetectionMode.paused:
        return '已暂停';
      case DetectionMode.error:
        return '错误';
    }
  }
}
