import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:tflite_flutter_helper/tflite_flutter_helper.dart';
import '../models/detection_result.dart';
import 'package:vector_math/vector_math.dart' as vector;

/// YOLO模型推理服务
/// 迁移自 Python 的 detection_thread.py 中的核心检测逻辑
class YoloService {
  late Interpreter _interpreter;
  late List<String> _labels;
  bool _isModelLoaded = false;
  
  // 模型配置参数
  static const int inputSize = 640;
  static const int numClasses = 80;
  static const double defaultConfidenceThreshold = 0.25;
  static const double defaultIoUThreshold = 0.45;

  YoloService();

  /// 初始化模型
  Future<void> initialize() async {
    try {
      // 加载模型文件
      final modelPath = await _getModelPath();
      
      // 创建解释器选项
      final interpreterOptions = InterpreterOptions();
      
      // 尝试使用GPU加速
      try {
        interpreterOptions.addDelegate(GpuDelegateV2());
      } catch (e) {
        print('GPU加速不可用，使用CPU模式: $e');
      }
      
      // 创建解释器
      _interpreter = await Interpreter.fromAsset(
        'models/yolov8s.tflite',
        options: interpreterOptions,
      );

      // 加载标签
      _labels = await _loadLabels();
      
      _isModelLoaded = true;
      print('YOLO模型加载成功');
    } catch (e) {
      print('YOLO模型加载失败: $e');
      rethrow;
    }
  }

  /// 获取模型路径
  Future<String> _getModelPath() async {
    // 实际项目中，模型文件应放在 assets/models/ 目录下
    return 'models/yolov8s.tflite';
  }

  /// 加载标签文件
  Future<List<String>> _loadLabels() async {
    // 返回 COCO 数据集的 80 个类别
    return [
      'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat', 'traffic light',
      'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep', 'cow',
      'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella', 'handbag', 'tie', 'suitcase', 'frisbee',
      'skis', 'snowboard', 'sports ball', 'kite', 'baseball bat', 'baseball glove', 'skateboard', 'surfboard',
      'tennis racket', 'bottle', 'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple',
      'sandwich', 'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
      'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote', 'keyboard', 'cell phone',
      'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book', 'clock', 'vase', 'scissors', 'teddy bear',
      'hair drier', 'toothbrush'
    ];
  }

  /// 处理图像并返回检测结果
  /// 对应 Python 的 process_frame 方法
  Future<List<DetectionResult>> detect({
    required Uint8List imageBytes,
    double confidenceThreshold = defaultConfidenceThreshold,
    Map<String, String>? customLabels,
  }) async {
    if (!_isModelLoaded) {
      throw Exception('模型未加载，请先调用 initialize()');
    }

    try {
      // 1. 预处理图像
      final processedImage = await _preprocessImage(imageBytes);
      
      // 2. 模型推理
      final output = await _runInference(processedImage);
      
      // 3. 后处理 - 解析检测结果
      final detections = _postprocessOutput(
        output,
        confidenceThreshold,
        customLabels,
      );
      
      return detections;
    } catch (e) {
      print('检测过程出错: $e');
      return [];
    }
  }

  /// 预处理图像
  Future<TensorImage> _preprocessImage(Uint8List imageBytes) async {
    // 解码图像
    final image = img.decodeImage(imageBytes)!;
    
    // 调整图像大小到模型输入尺寸
    final resized = img.copyResize(
      image,
      width: inputSize,
      height: inputSize,
      interpolation: img.Interpolation.linear,
    );
    
    // 转换为 RGB
    final rgbImage = img.Image(width: resized.width, height: resized.height);
    for (int y = 0; y < resized.height; y++) {
      for (int x = 0; x < resized.width; x++) {
        final pixel = resized.getPixel(x, y);
        rgbImage.setPixelRgba(x, y, pixel.r.toInt(), pixel.g.toInt(), pixel.b.toInt(), 255);
      }
    }
    
    // 转换为 TensorImage
    final tensorImage = TensorImage.fromImage(rgbImage);
    
    // 归一化到 [0, 1]
    final processor = ImageProcessorBuilder()
        .add(ResizeOp(inputSize, inputSize, ResizeMethod.BILINEAR))
        .add(NormalizeOp(0, 255))
        .build();
    
    return processor.process(tensorImage);
  }

  /// 运行模型推理
  Future<List<List<double>>> _runInference(TensorImage input) async {
    // 准备输入数据
    final inputBuffer = input.buffer;
    
    // 准备输出数据
    // YOLOv8 输出格式: [1, 8400, 85] (batch, num_detections, 4 + num_classes)
    final outputShape = _interpreter.getOutputTensor(0).shape;
    final outputSize = outputShape.reduce((a, b) => a * b);
    final outputBuffer = List<double>.filled(outputSize, 0.0).reshape(outputShape);
    
    // 运行推理
    _interpreter.run(inputBuffer.buffer, outputBuffer);
    
    return outputBuffer;
  }

  /// 后处理输出
  List<DetectionResult> _postprocessOutput(
    List<List<double>> output,
    double confidenceThreshold,
    Map<String, String>? customLabels,
  ) {
    final List<DetectionResult> detections = [];
    
    // YOLOv8 输出格式解析
    // output[0] 包含所有检测结果: [8400, 85]
    // 每一行: [x, y, w, h, conf, class0_conf, class1_conf, ...]
    
    for (int i = 0; i < output[0].length; i++) {
      final row = output[0][i];
      
      // 提取边界框中心点、宽度和高度
      final x = row[0];
      final y = row[1];
      final w = row[2];
      final h = row[3];
      
      // 转换为左上角和右下角坐标
      final x1 = x - w / 2;
      final y1 = y - h / 2;
      final x2 = x + w / 2;
      final y2 = y + h / 2;
      
      // 找到最大类别概率
      double maxClassConfidence = 0.0;
      int maxClassIndex = 0;
      
      for (int j = 4; j < row.length; j++) {
        if (row[j] > maxClassConfidence) {
          maxClassConfidence = row[j];
          maxClassIndex = j - 4;
        }
      }
      
      // 计算总体置信度
      final confidence = maxClassConfidence;
      
      // 过滤低置信度检测
      if (confidence < confidenceThreshold) {
        continue;
      }
      
      // 获取标签
      final originalLabel = _labels[maxClassIndex];
      final displayLabel = customLabels?[originalLabel] ?? originalLabel;
      
      // 创建检测结果
      detections.add(DetectionResult(
        label: displayLabel,
        confidence: confidence,
        boundingBox: Rect.fromLTWH(x1, y1, x2 - x1, y2 - y1),
        classId: maxClassIndex,
      ));
    }
    
    // 应用非极大值抑制 (NMS)
    return _applyNMS(detections, defaultIoUThreshold);
  }

  /// 非极大值抑制
  List<DetectionResult> _applyNMS(
    List<DetectionResult> detections,
    double iouThreshold,
  ) {
    if (detections.isEmpty) return detections;
    
    // 按置信度降序排序
    detections.sort((a, b) => b.confidence.compareTo(a.confidence));
    
    final List<DetectionResult> selectedDetections = [];
    final List<bool> suppressed = List.filled(detections.length, false);
    
    for (int i = 0; i < detections.length; i++) {
      if (suppressed[i]) continue;
      
      selectedDetections.add(detections[i]);
      
      for (int j = i + 1; j < detections.length; j++) {
        if (suppressed[j]) continue;
        
        // 只对同一类别进行 NMS
        if (detections[i].classId != detections[j].classId) continue;
        
        // 计算 IoU
        final iou = _calculateIoU(detections[i].boundingBox, detections[j].boundingBox);
        
        if (iou > iouThreshold) {
          suppressed[j] = true;
        }
      }
    }
    
    return selectedDetections;
  }

  /// 计算 IoU (Intersection over Union)
  double _calculateIoU(Rect box1, Rect box2) {
    final x1 = box1.left > box2.left ? box1.left : box2.left;
    final y1 = box1.top > box2.top ? box1.top : box2.top;
    final x2 = box1.right < box2.right ? box1.right : box2.right;
    final y2 = box1.bottom < box2.bottom ? box1.bottom : box2.bottom;
    
    final interArea = (x2 - x1).clamp(0.0, double.infinity) * 
                      (y2 - y1).clamp(0.0, double.infinity);
    
    final box1Area = (box1.right - box1.left) * (box1.bottom - box1.top);
    final box2Area = (box2.right - box2.left) * (box2.bottom - box2.top);
    
    final unionArea = box1Area + box2Area - interArea;
    
    return interArea / unionArea;
  }

  /// 释放资源
  void dispose() {
    if (_isModelLoaded) {
      _interpreter.close();
    }
  }

  /// 检查模型是否已加载
  bool get isModelLoaded => _isModelLoaded;
}
