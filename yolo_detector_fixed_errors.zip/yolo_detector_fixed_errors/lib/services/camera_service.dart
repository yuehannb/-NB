import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:image/image.dart' as img;
import 'package:permission_handler/permission_handler.dart';

/// 相机服务
/// 提供相机流获取和图像处理功能
class CameraService {
  CameraController? _controller;
  List<CameraDescription>? _cameras;
  bool _isInitialized = false;
  
  // FPS 计算
  int _frameCount = 0;
  DateTime? _fpsStartTime;
  double _currentFPS = 0.0;

  CameraService();

  /// 初始化相机
  Future<void> initialize() async {
    try {
      // 请求相机权限
      final permissionStatus = await Permission.camera.request();
      if (!permissionStatus.isGranted) {
        throw Exception('相机权限被拒绝');
      }

      // 获取可用相机
      _cameras = await availableCameras();
      if (_cameras == null || _cameras!.isEmpty) {
        throw Exception('未找到可用相机');
      }

      // 使用后置相机（如果有）
      final backCamera = _cameras!.firstWhere(
        (camera) => camera.lensDirection == CameraLensDirection.back,
        orElse: () => _cameras!.first,
      );

      // 创建相机控制器
      _controller = CameraController(
        backCamera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid
            ? ImageFormatGroup.nv21
            : ImageFormatGroup.bgra8888,
      );

      await _controller!.initialize();
      _isInitialized = true;
      
      // 开始 FPS 计算
      _startFPSCalculation();
      
      print('相机初始化成功');
    } catch (e) {
      print('相机初始化失败: $e');
      rethrow;
    }
  }

  /// 开始 FPS 计算
  void _startFPSCalculation() {
    _fpsStartTime = DateTime.now();
    _frameCount = 0;
  }

  /// 更新 FPS
  double updateFPS() {
    _frameCount++;
    final now = DateTime.now();
    final elapsed = now.difference(_fpsStartTime!).inMilliseconds;
    
    if (elapsed >= 1000) {
      _currentFPS = (_frameCount / elapsed) * 1000;
      _frameCount = 0;
      _fpsStartTime = now;
    }
    
    return _currentFPS;
  }

  /// 获取当前 FPS
  double get currentFPS => _currentFPS;

  /// 获取相机预览流
  CameraController? get controller => _controller;

  /// 检查相机是否已初始化
  bool get isInitialized => _isInitialized;

  /// 开始图像流
  void startImageStream(
    void Function(CameraImage image) onImageAvailable,
  ) {
    if (_controller != null && _isInitialized) {
      _controller!.startImageStream((image) {
        onImageAvailable(image);
        updateFPS();
      });
    }
  }

  /// 停止图像流
  void stopImageStream() {
    if (_controller != null) {
      _controller!.stopImageStream();
    }
  }

  /// 捕获单张图片
  Future<Uint8List> captureImage() async {
    if (_controller == null || !_isInitialized) {
      throw Exception('相机未初始化');
    }

    final XFile image = await _controller!.takePicture();
    return await image.readAsBytes();
  }

  /// 转换 CameraImage 为 Uint8List
  static Uint8List cameraImageToBytes(CameraImage image) {
    try {
      final width = image.width;
      final height = image.height;
      
      // 创建目标图像
      final img.Image resultImage = img.Image(width: width, height: height);
      
      // 根据图像格式进行转换
      switch (image.format.group) {
        case ImageFormatGroup.yuv420:
          _convertYUV420ToRGB(image, resultImage);
          break;
        case ImageFormatGroup.bgra8888:
          _convertBGRA8888ToRGB(image, resultImage);
          break;
        case ImageFormatGroup.jpeg:
          return image.planes[0].bytes;
        default:
          throw Exception('不支持的图像格式: ${image.format.group}');
      }
      
      return Uint8List.fromList(img.encodePng(resultImage));
    } catch (e) {
      print('图像转换失败: $e');
      rethrow;
    }
  }

  /// YUV420 转 RGB
  static void _convertYUV420ToRGB(CameraImage image, img.Image resultImage) {
    final yPlane = image.planes[0];
    final uPlane = image.planes[1];
    final vPlane = image.planes[2];
    
    final yBuffer = yPlane.bytes;
    final uBuffer = uPlane.bytes;
    final vBuffer = vPlane.bytes;
    
    final yRowStride = yPlane.bytesPerRow;
    final uvRowStride = uPlane.bytesPerRow;
    final uvPixelStride = uPlane.bytesPerPixel!;
    
    for (int y = 0; y < image.height; y++) {
      final uvOffset = (y >> 1) * uvRowStride;
      
      for (int x = 0; x < image.width; x++) {
        final yIndex = y * yRowStride + x;
        final uvIndex = uvOffset + (x >> 1) * uvPixelStride;
        
        final yValue = yBuffer[yIndex] & 0xff;
        final uValue = uBuffer[uvIndex] & 0xff;
        final vValue = vBuffer[uvIndex] & 0xff;
        
        // YUV 转 RGB
        final r = (yValue + 1.402 * (vValue - 128)).clamp(0, 255).toInt();
        final g = (yValue - 0.34414 * (uValue - 128) - 0.71414 * (vValue - 128))
            .clamp(0, 255)
            .toInt();
        final b = (yValue + 1.772 * (uValue - 128)).clamp(0, 255).toInt();
        
        resultImage.setPixelRgb(x, y, r, g, b);
      }
    }
  }

  /// BGRA8888 转 RGB
  static void _convertBGRA8888ToRGB(CameraImage image, img.Image resultImage) {
    final plane = image.planes[0];
    final bytes = plane.bytes;
    
    int byteIndex = 0;
    for (int y = 0; y < image.height; y++) {
      for (int x = 0; x < image.width; x++) {
        final b = bytes[byteIndex++];
        final g = bytes[byteIndex++];
        final r = bytes[byteIndex++];
        final a = bytes[byteIndex++];
        
        resultImage.setPixelRgb(x, y, r, g, b);
      }
    }
  }

  /// 调整图像大小
  static Uint8List resizeImage(
    Uint8List imageBytes,
    int targetWidth,
    int targetHeight,
  ) {
    try {
      final image = img.decodeImage(imageBytes)!;
      final resized = img.copyResize(
        image,
        width: targetWidth,
        height: targetHeight,
        interpolation: img.Interpolation.linear,
      );
      return Uint8List.fromList(img.encodePng(resized));
    } catch (e) {
      print('图像缩放失败: $e');
      rethrow;
    }
  }

  /// 旋转图像
  static Uint8List rotateImage(
    Uint8List imageBytes,
    int angle,
  ) {
    try {
      final image = img.decodeImage(imageBytes)!;
      img.Image rotated;
      
      switch (angle) {
        case 90:
          rotated = img.copyRotate(image, angle: 90);
          break;
        case 180:
          rotated = img.copyRotate(image, angle: 180);
          break;
        case 270:
          rotated = img.copyRotate(image, angle: 270);
          break;
        default:
          rotated = image;
      }
      
      return Uint8List.fromList(img.encodePng(rotated));
    } catch (e) {
      print('图像旋转失败: $e');
      rethrow;
    }
  }

  /// 释放资源
  Future<void> dispose() async {
    if (_controller != null) {
      await _controller!.dispose();
      _controller = null;
    }
    _isInitialized = false;
  }

  /// 切换相机（前后置）
  Future<void> switchCamera() async {
    if (_cameras == null || _cameras!.length < 2) {
      throw Exception('设备只有一个相机');
    }

    final isFront = _controller?.description.lensDirection == CameraLensDirection.front;
    final newCamera = isFront ? _cameras!.first : _cameras![1];

    await _controller?.dispose();
    
    _controller = CameraController(
      newCamera,
      ResolutionPreset.high,
      enableAudio: false,
    );

    await _controller!.initialize();
    _isInitialized = true;
  }
}
