import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// 自定义标签管理
/// 对应 Python 项目中的 custom_labels 功能
class CustomLabelsManager {
  static const String _storageKey = 'custom_labels';
  
  // 默认的 YOLOv8 标签
  static const Map<String, String> _defaultLabels = {
    'person': '人',
    'bicycle': '自行车',
    'car': '汽车',
    'motorcycle': '摩托车',
    'airplane': '飞机',
    'bus': '公交车',
    'train': '火车',
    'truck': '卡车',
    'boat': '船',
    'traffic light': '红绿灯',
    'fire hydrant': '消防栓',
    'stop sign': '停车标志',
    'parking meter': '停车计时器',
    'bench': '长椅',
    'bird': '鸟',
    'cat': '猫',
    'dog': '狗',
    'horse': '马',
    'sheep': '羊',
    'cow': '牛',
    'elephant': '大象',
    'bear': '熊',
    'zebra': '斑马',
    'giraffe': '长颈鹿',
    'backpack': '背包',
    'umbrella': '雨伞',
    'handbag': '手提包',
    'tie': '领带',
    'suitcase': '行李箱',
    'frisbee': '飞盘',
    'skis': '滑雪板',
    'snowboard': '滑雪板',
    'sports ball': '运动球',
    'kite': '风筝',
    'baseball bat': '棒球棒',
    'baseball glove': '棒球手套',
    'skateboard': '滑板',
    'surfboard': '冲浪板',
    'tennis racket': '网球拍',
    'bottle': '瓶子',
    'wine glass': '酒杯',
    'cup': '杯子',
    'fork': '叉子',
    'knife': '刀',
    'spoon': '勺子',
    'bowl': '碗',
    'banana': '香蕉',
    'apple': '苹果',
    'sandwich': '三明治',
    'orange': '橙子',
    'broccoli': '西兰花',
    'carrot': '胡萝卜',
    'hot dog': '热狗',
    'pizza': '披萨',
    'donut': '甜甜圈',
    'cake': '蛋糕',
    'chair': '椅子',
    'couch': '沙发',
    'potted plant': '盆栽',
    'bed': '床',
    'dining table': '餐桌',
    'toilet': '马桶',
    'tv': '电视',
    'laptop': '笔记本电脑',
    'mouse': '鼠标',
    'remote': '遥控器',
    'keyboard': '键盘',
    'cell phone': '手机',
    'microwave': '微波炉',
    'oven': '烤箱',
    'toaster': '烤面包机',
    'sink': '水槽',
    'refrigerator': '冰箱',
    'book': '书',
    'clock': '时钟',
    'vase': '花瓶',
    'scissors': '剪刀',
    'teddy bear': '泰迪熊',
    'hair drier': '吹风机',
    'toothbrush': '牙刷',
  };

  Map<String, String> _customLabels = {};

  /// 初始化，加载保存的自定义标签
  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final savedLabels = prefs.getString(_storageKey);
    
    if (savedLabels != null) {
      _customLabels = Map<String, String>.from(json.decode(savedLabels));
    } else {
      _customLabels = Map.from(_defaultLabels);
    }
  }

  /// 获取显示标签
  String getDisplayLabel(String originalLabel) {
    return _customLabels[originalLabel] ?? originalLabel;
  }

  /// 获取所有标签映射
  Map<String, String> getAllLabels() {
    return Map.from(_customLabels);
  }

  /// 更新标签
  Future<void> updateLabel(String originalLabel, String displayLabel) async {
    _customLabels[originalLabel] = displayLabel;
    await _saveLabels();
  }

  /// 批量更新标签
  Future<void> updateLabels(Map<String, String> labels) async {
    _customLabels.addAll(labels);
    await _saveLabels();
  }

  /// 重置为默认标签
  Future<void> resetToDefault() async {
    _customLabels = Map.from(_defaultLabels);
    await _saveLabels();
  }

  /// 保存标签到本地存储
  Future<void> _saveLabels() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, json.encode(_customLabels));
  }

  /// 获取默认标签列表
  static Map<String, String> getDefaultLabels() {
    return Map.from(_defaultLabels);
  }
}
