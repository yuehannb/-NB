/// 检测结果数据模型
/// 对应 Python 中的检测结果
class DetectionResult {
  final String label;
  final double confidence;
  final Rect boundingBox;
  final int classId;

  DetectionResult({
    required this.label,
    required this.confidence,
    required this.boundingBox,
    required this.classId,
  });

  @override
  String toString() {
    return 'DetectionResult(label: $label, confidence: ${confidence.toStringAsFixed(2)})';
  }

  /// 从模型输出创建检测结果
  factory DetectionResult.fromModelOutput(
    String label,
    double confidence,
    double x1,
    double y1,
    double x2,
    double y2,
    int classId,
  ) {
    return DetectionResult(
      label: label,
      confidence: confidence,
      boundingBox: Rect.fromLTWH(x1, y1, x2 - x1, y2 - y1),
      classId: classId,
    );
  }

  /// 复制并修改
  DetectionResult copyWith({
    String? label,
    double? confidence,
    Rect? boundingBox,
    int? classId,
  }) {
    return DetectionResult(
      label: label ?? this.label,
      confidence: confidence ?? this.confidence,
      boundingBox: boundingBox ?? this.boundingBox,
      classId: classId ?? this.classId,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'label': label,
      'confidence': confidence,
      'boundingBox': {
        'left': boundingBox.left,
        'top': boundingBox.top,
        'right': boundingBox.right,
        'bottom': boundingBox.bottom,
      },
      'classId': classId,
    };
  }
}

/// 矩形工具类
class Rect {
  final double left;
  final double top;
  final double right;
  final double bottom;

  Rect({
    required this.left,
    required this.top,
    required this.right,
    required this.bottom,
  });

  factory Rect.fromLTWH(double left, double top, double width, double height) {
    return Rect(
      left: left,
      top: top,
      right: left + width,
      bottom: top + height,
    );
  }

  double get width => right - left;
  double get height => bottom - top;
}
